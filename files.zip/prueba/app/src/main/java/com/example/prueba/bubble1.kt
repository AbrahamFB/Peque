package com.example.prueba

import android.os.Bundle
import android.provider.Settings.Global.getString
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import [com.tutorialwing.spinner].databinding.ActivityMainBinding

class bubble1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bubble1)
    }
    setupSpinner()
}

private fun setupSpinner() {
    val personNames = arrayOf("Rahul", "Jack", "Rajeev", "Aryan", "Rashmi", "Jaspreet", "Akbar")
    val spinner = binding.spinnerID
    val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, personNames)
    spinner.adapter = arrayAdapter

    spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(
            parent: AdapterView<*>,
            view: View,
            position: Int,
            id: Long
        ) {
            Toast.makeText(
                this@MainActivity, getString(R.string.selected_item) + " " + personNames[position],
                Toast.LENGTH_SHORT
            ).show()
        }

        override fun onNothingSelected(parent: AdapterView<*>) {
            // Code to perform some action when nothing is selected
        }
    }

}